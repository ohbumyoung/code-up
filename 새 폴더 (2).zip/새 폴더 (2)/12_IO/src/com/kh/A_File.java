package com.kh;

import java.io.File;
import java.io.IOException;

public class A_File {

	/*
	 File: 파일을 다루는 객체 (java.util에 있다.)
	 */
	public static void main(String[] args) {
		// method();
		method2();
		
	}
		public static void method1(){
		//File 객체 생성
		File f1 = new File("test1.txt");
		// 존재하지 않는 파일 이름만 가지고 객체 생성
		File f2 = new File("D:\\test2.txt");
		// 존재하는 파일의 경로포함 이름가지고 객체 생성
		File f3 = new File("D:\\test3.txt");
		// 특정 경로의 존재하지 않는 파일 이름만 가지고 객체 생성
		//File f4 = new File("D:\\temp\\test4.txt");
		// 존재하지 않는 경로에 파일 이름으로 객체 생성
		
		File f4_folder = new File("D:\\temp");
		File f4 = new File("D:\\temp\\test4.txt");
		
		File f5 = new File("test5.txt");
		
		// 파일이 존재하는지 확인: exists():boolean
		System.out.println("test1.txt 가 존재하는가?" + f1.exists());
		System.out.println("test5.txt 가 존재하는가?" + f5.exists());
		
		//파일인지 확인: isFile():boolean
		System.out.println("f4는 파일인가?" +f4.isFile());
		System.out.println("f4_folder 는 파일인가?" + f4_folder.isFile());
		
		try {
		f1.createNewFile();
		// f1 프로젝트 최상위 경로에 해당 파일 생성
		f2.createNewFile();
		// f2 존재하는 파일의 경우 따로 처리하는 내용이 없음
		f3.createNewFile();
		// f3 특정 경로(지정한 경로)에 파일을 생성
		//f4.createNewFile();
		// f4 존재하지 않는 경로에 파일을 생성하려고 하는 경우 예외 발생
		//-> 폴더를 먼저 생성하고, 그 다음에 파일을 생성
		
		// 폴더 생성: mkdir / mkdirs
		f4_folder.mkdir();
		f4.createNewFile();
		
		} catch(IOException e) {
			e.printStackTrace();
		}
	System.out.print("이해 안되는데......");
	

		
	}
		public static void method2() {
			/** sample 폴더를 생성하고, myDiary.txt 파일 생성하기
			 => sample/myDiary.txt 생성하기
			 */
			
			// sample 폴더가 없는 경우, 폴더 생성
			File folder = new File("sample");
			if(!folder.exists()) {
				folder.mkdir();
			}
			try {
			File f1 = new File("sample\\myDoary.txt");
			if(!f1.exists()) {
				f1.createNewFile();
				
			}
			
			//File 객체를 통해 파일 정보 조회
			System.out.println("파일명 : " + f1.getName());
			System.out.println("파일경로 : " + f1.getAbsolutePath());
			System.out.println("파일용량 : " + f1.length());
			System.out.println("파일상위 폴더 : " + f1.getParent());
				
			
			}catch(IOException e) {
				
			}
	}
		
		
	
}
