package com.kh;
import java.util.Scanner;
public class B_switch {
	
	public static void main(String[] args) {
		mathood1();
		
	}
	/*
	 조건문 switch
	 동등 비교를 통해 흐름을 제어
	 
	 [표현볍]
	 switch (비교대상 변수) {
	 	case 값1: 비교대상 변수 == 값1 일 때 실행할 내용
	 		break;
	 		
	    case 값2: 비교대상 변수 == 값2 일 때 실행할 내용
	 		break;
	 		.....
	 		
	 		default: 모든 case에 해당하지 않을 경우 실행할 내용
	 		break;
	 }
	 */

	public static void mathood1() {
		/*
		 정수를 입력 받아 아래 조건에 맞게 출력
		 1: 빨간색
		 2: 노란색
		 3: 초란색
		 그 외: 검은색
		 */
		
		Scanner sc= new Scanner(System.in);
		
		int color = sc.nextInt();
		
		switch(color) {
		case 1:System.out.print("빨간색");  //case 1 = 변수 값 1입력할때
		break;
		
	    case 2:System.out.print("노란색");  //case 2 = 변수 값 2입력할때
	    break;
	    
	    case 3:System.out.print("초록색");  //case 3 = 변수 값 3입력할때
	    break;
	    
	    default:System.out.print("검은색"); //default = 변수 값 4.5.6...정수 입력할때
	    break;
		}
	}
	public static void mathood2() {
		
		/*
		 * 사용자에게 두 개의 정수와 + 또는 -를 입력받아 연산 결과를 출력
		 * 단, + 또는 - 외의 문자가 입력되었을 경우 "입력이 잘못되었습니다." 출력
		 * 
		 * 입력 예시)10 20 +
		 * 출력 예시)10 + 20 = 30
		 * 
		 * 입력 예시)5 10 /
		 * 출력 예시)5 / 10 = 입력이 잘못되었습니다.
		 */
	
		Scanner sc = new Scanner(System.in);
		
		// => 비교대상 : 사용자가 입력한 기호 : op
		// => 비교할 값 : +, -
		
		int n1 = sc.nextInt(); 
		
		int n2 = sc.nextInt(); 
		
		String strOp = sc.next(); 
		
		char op = strOp.charAt(0); 
		
	    
	    switch(op) {
	    case '+': System.out.print("n1 + n2 = " + (n1 + n2)); 
	    break;
	    
	    case '-': System.out.print("n1 - n2 = " + (n1 - n2)); 
	    break;
	    
	    case '*': System.out.print("n1 * n2 = " + (n1 * n2)); 
	    break;
	    
	    case '/': System.out.print("n1 / n2 = " + (n1 / n2)); 
	    break;
	    
	    case '%': System.out.print("n1 % n2 = " + (n1 % n2));
	    break;
	    
	    default: System.out.print("입력이 잘못되었습니다.");
	    break;
	    
	    }

		
		
		
	}
	
	
	
}
